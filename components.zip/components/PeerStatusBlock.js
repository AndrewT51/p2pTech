import React, { Component } from 'react'
import StatusLight from './StatusLight'

import {
  StyleSheet,
  Text,
  ScrollView,
  View,
  Button
} from 'react-native'



export default class PeerStatusBlock extends Component {

  render(){
  const colours = ['red','red','red','orange','green','green']
  console.log('Prox', this.props.proximity)
    return (
      <View style={ styles.peerBlock }>
        <Text style={ styles.userID }>
          User: {this.props.peerID.split('-')[0]}
        </Text>
        <View style={styles.statusLight} >
          <StatusLight colour={colours[this.props.proximity] }/>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({


  userID: {
    flex:5,
    marginLeft: 15,
  },
  statusLight:{
    flex: 1,
  },
  peerBlock: {
    flexDirection: 'row',
    backgroundColor: '#E8FFFF',
    borderWidth: 1,
    borderColor: 'lightgrey',
    borderRadius: 5,
    marginLeft: 3,
    marginRight: 3,
    alignItems:'center',
    justifyContent: 'center',
    height: 50,
    marginTop: 2,
    marginBottom: 2
  },

});
