import React, { Component } from 'react'
import PeerStatusBlock from '../PeerStatusBlock'
import {
  StyleSheet,
  Text,
  ScrollView,
  View,
  Button
} from 'react-native'


export default class PeerStatusBlockList extends Component {

  renderBlocks(){
    if ( !this.props.peers.length ) return null
    return (
     this.props.peers.map((peer) => {
        return <PeerStatusBlock peerID={peer} key={peer} proximity={this.props.proximity[peer]} />
      })
    )
  }

  render(){
    return (
      <View style={styles.listContainer}>
        <ScrollView style={styles.container}>
            {this.renderBlocks.call(this)}
        </ScrollView>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  listContainer: {
    flex:1,
    flexDirection:'row'
  },
});

